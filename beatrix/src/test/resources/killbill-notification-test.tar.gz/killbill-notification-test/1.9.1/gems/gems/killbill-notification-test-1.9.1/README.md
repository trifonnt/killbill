killbill-notification-test-plugin
=================================

Plugin to test the Kill Bill NotificationPlugin API.


Release builds are available on [Maven Central](http://search.maven.org/#search%7Cga%7C1%7Cg%3A%22org.kill-bill.billing.plugin.ruby%22%20AND%20a%3A%22notification-test-plugin%22) with coordinates `org.kill-bill.billing.plugin.ruby:notification-test-plugin`.
