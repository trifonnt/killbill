require 'fileutils'

FileUtils.mkdir_p 'target'
