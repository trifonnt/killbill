require '<%= identifier %>'
require '<%= identifier %>/application'

run Sinatra::Application
