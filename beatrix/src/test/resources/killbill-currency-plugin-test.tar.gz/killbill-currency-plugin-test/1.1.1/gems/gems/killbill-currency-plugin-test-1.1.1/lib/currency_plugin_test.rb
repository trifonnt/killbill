require 'killbill'

require 'currency_plugin_test/api'
